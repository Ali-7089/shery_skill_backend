exports.url = {
    mongodb: 'mongodb://localhost/finalproect',
    jwtSecretKey: 'JWT Major Project Ket M01R3@'
}